// Define your coding challenges and levels
const challenges = [
    {
        level: 1,
        question: "Write a Python program to print 'Hello, World!'",
        answer: "print('Hello, World!')",
    },
    {
        level: 2,
        question: "Calculate the sum of two numbers: 5 and 3",
        answer: "print(5 + 3)",
    },
    {
        level: 3,
        question: "Write a Python program to find the factorial of 5",
        answer: `result = 1;
for i in range(1, 6):
    result *= i
result`,
    },
    // Add more challenges and levels here
];

// Initialize variables
let currentLevel = 1;
let score = 0;

// Get HTML elements
const levelNumber = document.getElementById("level-number");
const scoreElement = document.getElementById("score");
const challengeText = document.getElementById("challenge-text");
const codeEditor = document.getElementById("code-editor");
const runButton = document.getElementById("run-button");
const feedbackText = document.getElementById("feedback-text");

// Function to update the challenge
function updateChallenge() {
    const challenge = challenges.find((c) => c.level === currentLevel);
    if (challenge) {
        levelNumber.textContent = challenge.level;
        challengeText.textContent = challenge.question;
    } else {
        challengeText.textContent = "You've completed all available levels!";
        runButton.setAttribute("disabled", "true");
    }
}

// Function to check the user's code
function checkCode() {
    const challenge = challenges.find((c) => c.level === currentLevel);
    if (!challenge) {
        return;
    }

    const userCode = codeEditor.value.trim();
    if (userCode === challenge.answer) {
        score += 10;
        scoreElement.textContent = score;
        currentLevel++;
        updateChallenge();
        feedbackText.textContent = "Correct! Move on to the next challenge.";
        codeEditor.value = "";
    } else {
        feedbackText.textContent = "Incorrect. Try again.";
    }
}

// Event listeners
runButton.addEventListener("click", checkCode);

// Initialize the first challenge
updateChallenge();
